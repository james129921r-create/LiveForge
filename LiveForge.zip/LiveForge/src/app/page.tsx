'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { AppShell, type SidebarTab } from '@/components/layout/AppShell';
import { MultiStreamGrid } from '@/features/multistream/components';
import { ChatPanel } from '@/features/chat/components';
import { useSettingsStore } from '@/stores/settingsStore';
import { useMultiStreamStore } from '@/stores/multiStreamStore';
import { usePlayerStore } from '@/stores/playerStore';
import { decodeLayout } from '@/lib/layout-share';
import type { SharedLayoutData } from '@/lib/layout-share';
import type { GridLayout } from '@/types';
import { PopOutPlayer } from '@/features/player/components/PopOutPlayer';

type SidePanel = 'stats' | 'downloads' | 'casting' | 'notifications' | 'diagnostics' | 'audioMixer' | 'streamGroups' | 'workspaces' | 'chatAlerts' | null;

// Global error suppression for non-critical browser/HLS errors
function useGlobalErrorSuppression() {
  useEffect(() => {
    // Suppress ResizeObserver loop errors (common with resizable panels, non-critical)
    const resizeObserverErr = (e: ErrorEvent) => {
      if (e.message === 'ResizeObserver loop completed with undelivered notifications.' ||
          e.message === 'ResizeObserver loop limit exceeded') {
        e.stopImmediatePropagation();
        e.preventDefault();
      }
    };
    window.addEventListener('error', resizeObserverErr);

    // Suppress unhandled promise rejections from HLS.js non-fatal errors
    const promiseRejection = (e: PromiseRejectionEvent) => {
      const reason = String(e.reason);
      if (reason.includes('bufferStalledError') || reason.includes('bufferAppendError')) {
        e.preventDefault();
      }
    };
    window.addEventListener('unhandledrejection', promiseRejection);

    return () => {
      window.removeEventListener('error', resizeObserverErr);
      window.removeEventListener('unhandledrejection', promiseRejection);
    };
  }, []);
}

export default function Home() {
  const [activeSidebarTab, setActiveSidebarTab] = useState<SidebarTab>('discover');
  const [activeSidePanel, setActiveSidePanel] = useState<SidePanel>(null);
  const { theme, accentColor, uiDensity, reducedMotion } = useSettingsStore();
  const { slots, setLayout, addChannelToSlot, clearAll } = useMultiStreamStore();

  // Suppress non-critical browser errors
  useGlobalErrorSuppression();

  // ─── Pop-out detection ────────────────────────────────────────────────────
  const [isPopOutWindow, setIsPopOutWindow] = useState(false);
  const [popOutChannelSlug, setPopOutChannelSlug] = useState('');
  const [popOutHlsUrl, setPopOutHlsUrl] = useState('');

  // ─── Shared Layout Loading ────────────────────────────────────────────────
  const [sharedLayoutLoading, setSharedLayoutLoading] = useState(false);
  const sharedLayoutProcessed = useRef(false);

  const loadSharedLayout = useCallback(async (data: SharedLayoutData) => {
    setSharedLayoutLoading(true);
    try {
      // Clear current layout
      clearAll();

      // Set the layout type
      const validLayouts: GridLayout[] = ['1x1', '1+2', '2+1', '2x2', '1+3', '1+1+2', '3x3'];
      if (validLayouts.includes(data.l as GridLayout)) {
        setLayout(data.l as GridLayout);
      }

      // Load channels into slots
      for (const slot of data.s) {
        try {
          const { fetchChannel } = await import('@/lib/kick-api');
          const channel = await fetchChannel(slot.c);
          if (channel) {
            addChannelToSlot(`slot-${slot.p}`, channel);
          }
        } catch {
          // Skip channels that fail to load
        }
      }

      // Restore audio settings
      const { setStreamVolume, setStreamMuted } = usePlayerStore.getState();
      if (data.a) {
        for (const [slotId, vol] of Object.entries(data.a)) {
          setStreamVolume(slotId, vol);
        }
      }
      if (data.m) {
        for (const [slotId, muted] of Object.entries(data.m)) {
          setStreamMuted(slotId, muted);
        }
      }

      // Switch to chat tab
      setActiveSidebarTab('chat');
    } catch {
      // Failed to load shared layout — ignore
    } finally {
      setSharedLayoutLoading(false);
      // Clean the URL
      if (typeof window !== 'undefined') {
        const url = new URL(window.location.href);
        url.searchParams.delete('layout');
        window.history.replaceState({}, '', url.toString());
      }
    }
  }, [clearAll, setLayout, addChannelToSlot]);

  // Pop-out detection effect
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    const popoutParam = params.get('popout');
    if (popoutParam) {
      setIsPopOutWindow(true);
      setPopOutChannelSlug(params.get('channel') || '');
      setPopOutHlsUrl(params.get('hls') || '');
      // Apply volume from params
      const volume = parseFloat(params.get('volume') || '0.75');
      const muted = params.get('muted') === 'true';
      usePlayerStore.getState().setVolume(volume);
      usePlayerStore.getState().setMuted(muted);
    }
  }, []);

  // Check URL for shared layout on mount
  useEffect(() => {
    if (sharedLayoutProcessed.current) return;
    sharedLayoutProcessed.current = true;

    const params = new URLSearchParams(window.location.search);
    const layoutParam = params.get('layout');
    if (layoutParam) {
      const decoded = decodeLayout(layoutParam);
      if (decoded) {
        loadSharedLayout(decoded);
      }
    }
  }, [loadSharedLayout]);

  // Auto-switch sidebar to Chat tab when a stream is added to a slot
  const prevChannelCountRef = useRef(0);
  useEffect(() => {
    const currentCount = slots.filter((s) => s.channel).length;
    if (currentCount > prevChannelCountRef.current && prevChannelCountRef.current >= 0) {
      // A stream was added — switch to Chat tab
      setActiveSidebarTab('chat');
    }
    prevChannelCountRef.current = currentCount;
  }, [slots]);

  // Apply theme, accent, and density to <html>
  useEffect(() => {
    const root = document.documentElement;

    // Theme
    if (theme === 'dark') {
      root.classList.add('dark');
    } else if (theme === 'light') {
      root.classList.remove('dark');
    } else {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      root.classList.toggle('dark', prefersDark);
    }

    // Accent color
    root.setAttribute('data-accent', accentColor);

    // UI density
    root.setAttribute('data-density', uiDensity);

    // Reduced motion
    if (reducedMotion) {
      root.style.setProperty('--motion-duration', '0ms');
    } else {
      root.style.removeProperty('--motion-duration');
    }

    // Update theme-color meta tag
    const metaThemeColor = document.querySelector('meta[name="theme-color"]');
    if (metaThemeColor) {
      metaThemeColor.setAttribute('content', root.classList.contains('dark') ? '#0a0a0a' : '#ffffff');
    }
  }, [theme, accentColor, uiDensity, reducedMotion]);

  // Listen for system theme changes when in 'system' mode
  useEffect(() => {
    if (theme !== 'system') return;

    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = (e: MediaQueryListEvent) => {
      document.documentElement.classList.toggle('dark', e.matches);
    };
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [theme]);

  // ─── Pop-out rendering ────────────────────────────────────────────────────
  // If this is a pop-out window, render just the player (all hooks called above)
  if (isPopOutWindow) {
    return <PopOutPlayer channelSlug={popOutChannelSlug} hlsUrl={popOutHlsUrl} />;
  }

  // ─── Normal rendering ─────────────────────────────────────────────────────
  return (
    <AppShell
      chatPanel={<ChatPanel />}
      activeSidebarTab={activeSidebarTab}
      onSidebarTabChange={setActiveSidebarTab}
      activeSidePanel={activeSidePanel}
      onSidePanelChange={setActiveSidePanel}
    >
      {sharedLayoutLoading && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm">
          <div className="flex flex-col items-center gap-3">
            <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full" />
            <p className="text-sm font-medium">Loading shared layout...</p>
          </div>
        </div>
      )}
      <MultiStreamGrid onOpenSearch={() => setActiveSidebarTab('discover')} />
    </AppShell>
  );
}
