import { NextRequest, NextResponse } from 'next/server';
import { RateLimiter } from '@/lib/rate-limit';

const ALLOWED_HOSTS = [
  'playback.live-video.net',
  'playlist.live-video.net',
  'stream.kick.com',
  'files.kick.com',
  'cf-hls-media.kick.com',
  'kick.com',
  'vod-cdn.kick.com',
  'thumb-cdn.kick.com',
  'clips-cdn.kick.com',
  'images.kick.com',
  'assets.kick.com',
  // AWS CloudFront distributions used by Kick (explicit IDs only — no wildcards to prevent SSRF)
  'd1ymq67oymj63v.cloudfront.net',
  'd2nvs31859zcd8.cloudfront.net',
  'd3vd9lf5q06oi0.cloudfront.net',
  // IVS playback domains (explicit subdomains only)
  'playback.live-video.net',
  'playlist.live-video.net',
  // Kick CDN domains
  '.kick.com',
];

/**
 * CDN host validation — only proxy from allowed Kick CDN domains.
 * This is a stricter check than the ALLOWED_HOSTS list above,
 * specifically for the HLS proxy which should only serve video content.
 */
const ALLOWED_CDN_HOSTS = [
  'playback.live-video.net',
  'playlist.live-video.net',
  'cf-hls-media.kick.com',
  'stream.kick.com',
  'files.kick.com',
  'd1ymq67oymj63v.cloudfront.net',
  'd2nvs31859zcd8.cloudfront.net',
  'd3vd9lf5q06oi0.cloudfront.net',
  // Allow any Kick-owned subdomain for video delivery
  '.kick.com',
];

// Per-IP rate limiter for HLS proxy — 60 requests per minute per IP
// This is tighter than the general middleware limiter because HLS segments
// are expensive to proxy and clients request them frequently during playback.
const hlsRateLimiter = new RateLimiter({ maxRequests: 60, windowMs: 60_000 });

function getClientIp(request: NextRequest): string {
  const forwarded = request.headers.get('x-forwarded-for');
  if (forwarded) return forwarded.split(',')[0]!.trim();
  const realIp = request.headers.get('x-real-ip');
  if (realIp) return realIp.trim();
  return 'unknown';
}

// Maximum response size: 10MB for HLS segments
const MAX_RESPONSE_SIZE = 10 * 1024 * 1024;

// Maximum URL path length
// NOTE: IVS sub-playlist URLs can be ~1000+ characters long due to signed tokens.
// The old limit of 512 caused ALL sub-playlist fetches to return 414, breaking playback.
const MAX_PATH_LENGTH = 2048;

// Timeout: 20s for segments, 15s for manifests
const SEGMENT_TIMEOUT_MS = 20_000;
const MANIFEST_TIMEOUT_MS = 15_000;

// Max retries for segment fetches
const MAX_SEGMENT_RETRIES = 1;

// Blocked paths that should never be proxied
// NOTE: '/api/' is NOT blocked here because Kick/IVS HLS playback URLs
// legitimately contain '/api/video/v1/...' in their path. The host allowlist
// already prevents SSRF — only CDN/video hosts are reachable.
const BLOCKED_PATHS = [
  '/admin',
  '/internal',
  '/private',
  '/auth',
  '/login',
  '/graphql',
  '/.env',
  '/.git',
  '/wp-',
];

// Blocked query parameter keys
// NOTE: 'token' and 'key' are NOT blocked because Kick/IVS HLS URLs legitimately
// use ?token= (JWT auth) and ?key= (encryption key) query parameters. The host
// allowlist already ensures only CDN/video hosts are reachable.
const BLOCKED_QUERY_KEYS = [
  'secret',
  'password',
  'auth',
];

/**
 * Rewrite URLs inside M3U8 manifests so they also go through our proxy.
 * This is the CRITICAL fix — without this, the browser tries to fetch
 * segment/key URLs directly from Kick's CDN and gets CORS errors.
 */
function rewriteM3U8Manifest(content: string, originalHost: string, originalPath: string): string {
  const proxyBase = '/api/kick/proxy/hls';

  // Normalize line endings to handle both LF and CRLF
  const lines = content.split(/\r?\n/);
  const rewritten: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]!;

    // Skip comment lines that aren't URI directives
    if (line.startsWith('#')) {
      // Rewrite URI= attributes in #EXT-X-KEY and #EXT-X-MEDIA lines
      if (line.includes('URI="')) {
        const rewrittenLine = line.replace(/URI="([^"]+)"/g, (match, url: string) => {
          const proxiedUrl = rewriteSingleUrl(url, originalHost, originalPath, proxyBase);
          return `URI="${proxiedUrl}"`;
        });
        rewritten.push(rewrittenLine);
      } else {
        rewritten.push(line);
      }
      continue;
    }

    // Empty line
    if (!line.trim()) {
      rewritten.push(line);
      continue;
    }

    // This is a URL line — rewrite it
    const rewrittenUrl = rewriteSingleUrl(line.trim(), originalHost, originalPath, proxyBase);
    rewritten.push(rewrittenUrl);
  }

  return rewritten.join('\n');
}

/**
 * Rewrite a single URL to go through our proxy.
 * Handles both absolute URLs (https://...) and relative URLs.
 */
function rewriteSingleUrl(url: string, originalHost: string, originalPath: string, proxyBase: string): string {
  // Already proxied?
  if (url.startsWith(proxyBase + '/') || url.startsWith('/' + proxyBase + '/')) {
    return url;
  }

  try {
    // Absolute URL
    if (url.startsWith('https://') || url.startsWith('http://')) {
      const parsed = new URL(url);
      const isAllowed = ALLOWED_HOSTS.some(h => parsed.hostname === h || parsed.hostname.endsWith('.' + h));
      if (isAllowed) {
        return `${proxyBase}/${parsed.hostname}${parsed.pathname}${parsed.search}`;
      }
      // Not an allowed host — return as-is (might be a different CDN)
      return url;
    }

    // Relative URL — resolve against the original host/path
    // e.g., "segment00000.ts" → "/api/kick/proxy/hls/playback.live-video.net/path/to/segment00000.ts"
    if (url.startsWith('/')) {
      // Absolute path on same host
      return `${proxyBase}/${originalHost}${url}`;
    }

    // Relative path — resolve against the directory of the original M3U8
    const dir = originalPath.includes('/') ? originalPath.substring(0, originalPath.lastIndexOf('/') + 1) : '';
    return `${proxyBase}/${originalHost}${dir}${url}`;
  } catch {
    return url;
  }
}

/**
 * Validate that the host is a recognized CDN domain for HLS content.
 * Returns true if the host is allowed for HLS proxying.
 */
function isValidCdnHost(host: string): boolean {
  return ALLOWED_CDN_HOSTS.some(allowed => {
    // Wildcard prefix (e.g., ".cloudfront.net" matches "d1ymq67oymj63v.cloudfront.net")
    if (allowed.startsWith('.')) {
      return host.endsWith(allowed) || host === allowed.slice(1);
    }
    // Exact match or subdomain match
    return host === allowed || host.endsWith('.' + allowed);
  });
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  // Per-IP rate limiting
  const clientIp = getClientIp(request);
  const rateLimit = hlsRateLimiter.check(clientIp);
  if (!rateLimit.allowed) {
    return NextResponse.json(
      { error: 'Too many requests', retryAfter: Math.ceil((rateLimit.resetTime - Date.now()) / 1000) },
      {
        status: 429,
        headers: {
          'Retry-After': String(Math.ceil((rateLimit.resetTime - Date.now()) / 1000)),
          'X-RateLimit-Remaining': '0',
          'X-RateLimit-Reset': String(rateLimit.resetTime),
        },
      }
    );
  }

  const startTime = Date.now();
  const { path } = await params;

  // Validate minimum path segments (need at least host + one path segment)
  if (!path || path.length < 2) {
    return NextResponse.json({ error: 'Invalid proxy path' }, { status: 400 });
  }

  const fullPath = path.join('/');

  // Validate total path length
  if (fullPath.length > MAX_PATH_LENGTH) {
    return NextResponse.json({ error: 'Path too long' }, { status: 414 });
  }

  // Reconstruct the target URL from the path
  // Format: /api/kick/proxy/hls/{host}/{rest_of_path}?{query}
  const host = path[0]!;
  const restPath = path.slice(1).join('/');

  // CDN host validation — stricter check for HLS proxy
  if (!isValidCdnHost(host)) {
    console.warn(`[hls-proxy] Blocked request to non-CDN host: ${host}`);
    return NextResponse.json(
      { error: `Host not allowed for HLS proxy: ${host}. Only Kick CDN domains are permitted.` },
      { status: 403 }
    );
  }

  // Also check general allowlist for compatibility
  const isAllowed = ALLOWED_HOSTS.some(allowed => {
    // Wildcard prefix (e.g., ".cloudfront.net" matches "d1ymq67oymj63v.cloudfront.net")
    if (allowed.startsWith('.')) {
      return host.endsWith(allowed) || host === allowed.slice(1);
    }
    // Exact match or subdomain match
    return host === allowed || host.endsWith('.' + allowed);
  });
  if (!isAllowed) {
    return NextResponse.json(
      { error: `Host not allowed: ${host}. Only Kick CDN domains are permitted.` },
      { status: 403 }
    );
  }

  // Block suspicious paths
  const normalizedPath = '/' + restPath.toLowerCase();
  if (BLOCKED_PATHS.some(blocked => normalizedPath.startsWith(blocked))) {
    return NextResponse.json({ error: 'Path not allowed' }, { status: 403 });
  }

  // Validate path doesn't contain directory traversal or null bytes
  if (restPath.includes('..') || restPath.includes('\\') || restPath.includes('\0')) {
    return NextResponse.json({ error: 'Invalid path' }, { status: 400 });
  }

  // Validate each path segment doesn't contain suspicious characters
  for (const segment of path) {
    if (segment.includes('\0')) {
      return NextResponse.json({ error: 'Invalid path segment' }, { status: 400 });
    }
    // NOTE: IVS signed sub-playlist URLs have a single path segment that's ~900+ chars.
    // We only need to check for null bytes; length limits are handled by MAX_PATH_LENGTH above.
  }

  const url = new URL(request.url);
  const queryString = url.search ? url.search : '';

  // Validate query parameters — block sensitive keys
  if (queryString) {
    const queryParams = new URLSearchParams(queryString);
    for (const key of queryParams.keys()) {
      if (BLOCKED_QUERY_KEYS.some(blocked => key.toLowerCase().includes(blocked))) {
        return NextResponse.json({ error: 'Disallowed query parameter' }, { status: 400 });
      }
    }
  }

  // Build the target URL
  const targetUrl = `https://${host}/${restPath}${queryString}`;

  // Final URL validation
  try {
    const parsedUrl = new URL(targetUrl);
    if (parsedUrl.protocol !== 'https:') {
      return NextResponse.json({ error: 'Only HTTPS allowed' }, { status: 400 });
    }
  } catch {
    return NextResponse.json({ error: 'Invalid target URL' }, { status: 400 });
  }

  try {
    // Determine if this is a segment request (for longer timeout and retry)
    const isSegmentRequest = restPath.endsWith('.ts') || restPath.endsWith('.m4s') || restPath.endsWith('.mp4') || restPath.endsWith('.key') || restPath.endsWith('.init');
    const timeoutMs = isSegmentRequest ? SEGMENT_TIMEOUT_MS : MANIFEST_TIMEOUT_MS;
    const maxRetries = isSegmentRequest ? MAX_SEGMENT_RETRIES : 0;

    let response: Response | null = null;
    let lastError: Error | null = null;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

        response = await fetch(targetUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
            'Accept': '*/*',
            'Accept-Encoding': 'identity',  // Don't request compressed segments — avoid decompression overhead
            'Referer': 'https://kick.com/',
            'Origin': 'https://kick.com',
          },
          signal: controller.signal,
          redirect: 'follow',
        });

        clearTimeout(timeoutId);

        if (response.ok) break; // Success — exit retry loop

        // If not OK and this is the last attempt, fall through to error handling
        if (attempt === maxRetries) break;

        console.warn(`[hls-proxy] Attempt ${attempt + 1} failed: ${response.status}, retrying...`);
      } catch (fetchErr) {
        lastError = fetchErr as Error;
        if (attempt < maxRetries) {
          console.warn(`[hls-proxy] Fetch attempt ${attempt + 1} failed, retrying...`);
          // Small delay before retry
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      }
    }

    if (!response) {
      const elapsed = Date.now() - startTime;
      console.error(`[hls-proxy] All fetch attempts failed after ${elapsed}ms for ${host}/${restPath.slice(0, 50)}`);
      if (lastError?.name === 'AbortError') {
        return NextResponse.json(
          { error: 'Upstream timeout' },
          { status: 504 }
        );
      }
      console.error('[hls-proxy] All fetch attempts failed:', lastError);
      return NextResponse.json(
        { error: 'Proxy fetch failed' },
        { status: 500 }
      );
    }

    if (!response.ok) {
      const elapsed = Date.now() - startTime;
      // Handle specific upstream errors with user-friendly messages
      if (response.status === 404) {
        console.log(`[hls-proxy] 404 after ${elapsed}ms for ${host}/${restPath.slice(0, 50)}`);
        // IVS returns 404 when the channel is not streaming or the stream has ended
        return NextResponse.json(
          { error: 'Stream not found — the channel may be offline or the stream has ended', status: 404 },
          { status: 404 }
        );
      }
      if (response.status === 403) {
        console.log(`[hls-proxy] 403 after ${elapsed}ms for ${host}/${restPath.slice(0, 50)}`);
        // Token expired or access denied
        return NextResponse.json(
          { error: 'Stream access denied — the playback token may have expired. Try refreshing.', status: 403 },
          { status: 403 }
        );
      }
      console.warn(`[hls-proxy] Upstream ${response.status} after ${elapsed}ms for ${host}/${restPath.slice(0, 50)}`);
      // Don't leak other upstream error details
      return NextResponse.json(
        { error: 'Upstream error', status: response.status },
        { status: response.status }
      );
    }

    const contentType = response.headers.get('content-type') || 'application/octet-stream';
    const body = await response.arrayBuffer();

    // Enforce maximum response size
    if (body.byteLength > MAX_RESPONSE_SIZE) {
      return NextResponse.json(
        { error: 'Response too large' },
        { status: 413 }
      );
    }

    // ─── M3U8 Manifest Rewriting ────────────────────────────────────────
    // This is the KEY fix: rewrite all URLs inside M3U8 manifests to go
    // through our proxy, so the browser never tries to hit Kick's CDN directly.
    const isM3U8 = contentType.includes('mpegurl') ||
      contentType.includes('vnd.apple') ||
      restPath.endsWith('.m3u8') ||
      restPath.endsWith('.m3u');

    if (isM3U8) {
      const text = new TextDecoder().decode(body);

      // Validate it's actually an M3U8
      if (!text.trimStart().startsWith('#EXTM3U')) {
        return NextResponse.json(
          { error: 'Invalid M3U8 manifest' },
          { status: 400 }
        );
      }

      // Rewrite URLs inside the manifest
      const rewritten = rewriteM3U8Manifest(text, host, restPath);

      const elapsed = Date.now() - startTime;
      console.log(`[hls-proxy] Manifest proxied in ${elapsed}ms for ${host}/${restPath.slice(0, 50)} (${rewritten.length} bytes)`);

      return new NextResponse(rewritten, {
        status: 200,
        headers: {
          'Content-Type': 'application/vnd.apple.mpegurl',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, OPTIONS',
          'Access-Control-Allow-Headers': 'Range, Accept, Accept-Encoding',
          'Access-Control-Expose-Headers': 'Content-Length, Content-Range',
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'X-Content-Type-Options': 'nosniff',
          'X-Proxy-Timing': String(elapsed),
          'X-RateLimit-Remaining': String(rateLimit.remaining),
          'X-RateLimit-Reset': String(rateLimit.resetTime),
        },
      });
    }

    // ─── Binary segments (TS, MP4, m4s, init, key, etc.) ────────────────
    // Allow a wider range of content types for video segments
    const allowedContentTypes = [
      'video/mp2t',
      'video/mp4',
      'video/MP2T',
      'video/iso.segment',
      'application/octet-stream',
      'binary/octet-stream',
      'application/vnd.apple.mpegurl',
      'text/plain',
    ];
    const isSafeContentType = allowedContentTypes.some(t => contentType.includes(t));
    if (!isSafeContentType) {
      // Be lenient: if the data looks like valid binary/video content, serve it anyway.
      // Check if the data size is reasonable for a segment and the path has a known extension.
      const looksLikeValidSegment = isSegmentRequest && body.byteLength > 0 && body.byteLength < MAX_RESPONSE_SIZE;
      if (!looksLikeValidSegment) {
        console.warn('[hls-proxy] Unexpected content type for non-segment:', contentType, 'path:', restPath);
        // Still serve it — CDNs sometimes return unexpected types
      }
      // Log but don't block — we've already validated the host and path
      // (CDNs sometimes return unexpected content types for valid segments)
    }

    // Determine cache control based on content type
    const isSegment = restPath.endsWith('.ts') || restPath.endsWith('.m4s') || restPath.endsWith('.mp4') || restPath.endsWith('.key') || restPath.endsWith('.init');
    const cacheControl = isSegment
      ? 'public, max-age=300'  // Segments can be cached for 5 min
      : 'no-cache';            // Everything else: no cache

    const elapsed = Date.now() - startTime;
    if (isSegment && elapsed > 5000) {
      // Log slow segment fetches
      console.warn(`[hls-proxy] Slow segment: ${elapsed}ms for ${host}/${restPath.slice(-30)} (${body.byteLength} bytes)`);
    }

    return new NextResponse(body, {
      status: 200,
      headers: {
        'Content-Type': contentType,
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Range, Accept, Accept-Encoding',
        'Access-Control-Expose-Headers': 'Content-Length, Content-Range',
        'Cache-Control': cacheControl,
        'X-Content-Type-Options': 'nosniff',
        'X-Proxy-Timing': String(elapsed),
        'X-RateLimit-Remaining': String(rateLimit.remaining),
        'X-RateLimit-Reset': String(rateLimit.resetTime),
      },
    });
  } catch (error) {
    const elapsed = Date.now() - startTime;
    if ((error as Error).name === 'AbortError') {
      console.error(`[hls-proxy] Timeout after ${elapsed}ms for ${host}/${restPath.slice(0, 50)}`);
      return NextResponse.json(
        { error: 'Upstream timeout' },
        { status: 504 }
      );
    }
    console.error(`[hls-proxy] Error after ${elapsed}ms:`, error);
    return NextResponse.json(
      { error: 'Proxy fetch failed' },
      { status: 500 }
    );
  }
}
