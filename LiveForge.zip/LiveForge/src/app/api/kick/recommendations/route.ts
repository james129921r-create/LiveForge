import { NextRequest, NextResponse } from 'next/server';
import { fetchKickChannel, fetchKickCategories, fetchKickCategoryLivestreams } from '@/lib/kick-fetch';
import { normalizeChannel, normalizeLivestream, normalizeCategory, CATEGORY_CHANNEL_MAP, RELATED_CATEGORIES } from '@/lib/normalize-channel';
import { safeParseInt } from '@/lib/parse-utils';
import type { StreamChannel } from '@/types';

/**
 * GET /api/kick/recommendations
 *
 * Returns "More Like This" recommendations based on a channel or category.
 * Finds streams in the same or related categories.
 *
 * Query params:
 *   - channel: channel slug to find similar streams for
 *   - category: category slug to find streams in
 *   - limit: max results (default 8, max 20)
 */

/**
 * Fuzzy-match a category slug against the known map keys.
 */
function findCategorySlug(input: string): string | null {
  const lower = input.toLowerCase().replace(/\s+/g, '-');
  if (CATEGORY_CHANNEL_MAP[lower]) return lower;
  // Try partial match
  const key = Object.keys(CATEGORY_CHANNEL_MAP).find(
    k => k.includes(lower) || lower.includes(k)
  );
  return key || null;
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const channelSlug = searchParams.get('channel')?.trim().toLowerCase() || '';
  const categorySlug = searchParams.get('category')?.trim().toLowerCase() || '';
  const limit = safeParseInt(searchParams.get('limit'), 8, 1, 20);

  if (!channelSlug && !categorySlug) {
    return NextResponse.json(
      { error: 'Provide either "channel" or "category" parameter' },
      { status: 400 }
    );
  }

  try {
    let targetCategory = categorySlug;
    const excludeSlug = channelSlug;

    // If a channel slug is provided, look up its category first
    if (channelSlug && !categorySlug) {
      try {
        const res = await fetchKickChannel(channelSlug);
        if (res.ok && res.data) {
          const data = res.data as Record<string, unknown>;
          const livestream = data.livestream as Record<string, unknown> | undefined;
          const recentCategories = data.recent_categories as Array<Record<string, unknown>> | undefined;
          const categories = livestream?.categories as Array<Record<string, unknown>> | undefined;
          const catObj = categories?.[0] || recentCategories?.[0];
          if (catObj) {
            const catSlug = catObj.slug as string || '';
            targetCategory = catSlug;
          }
        }
      } catch {
        // Continue without category info
      }
    }

    // Find the matched category in our map
    const matchedSlug = targetCategory ? findCategorySlug(targetCategory) : null;

    const channels: StreamChannel[] = [];
    const seenUsernames = new Set<string>();
    const MAX_LOOKUPS = 25;

    // ── Primary Strategy: Use fetchKickCategoryLivestreams() to get live streams ──
    if (matchedSlug) {
      try {
        const livestreamsRes = await fetchKickCategoryLivestreams(matchedSlug, 1, 30);
        if (livestreamsRes.ok && livestreamsRes.data) {
          const livestreamsData = livestreamsRes.data as { data?: Array<Record<string, unknown>> } | Array<Record<string, unknown>>;
          const streamItems = Array.isArray(livestreamsData) ? livestreamsData : ((livestreamsData as Record<string, unknown>).data as Array<Record<string, unknown>>) || [];

          if (Array.isArray(streamItems) && streamItems.length > 0) {
            for (const item of streamItems) {
              const normalized = normalizeLivestream(item);
              if (normalized && !seenUsernames.has(normalized.username)) {
                channels.push(normalized);
                seenUsernames.add(normalized.username);
              }
            }
          }
        }
      } catch (error) {
        console.warn('[recommendations] Primary strategy failed:', (error as Error).message);
      }

      // ── Related categories expansion: fetch from related categories too ──
      const relatedSlugs = RELATED_CATEGORIES[matchedSlug] || [];
      for (const relSlug of relatedSlugs.slice(0, 2)) { // Limit to 2 related categories
        if (channels.length >= limit + 3) break; // Already have enough
        try {
          const relLivestreamsRes = await fetchKickCategoryLivestreams(relSlug, 1, 15);
          if (relLivestreamsRes.ok && relLivestreamsRes.data) {
            const relData = relLivestreamsRes.data as { data?: Array<Record<string, unknown>> } | Array<Record<string, unknown>>;
            const relItems = Array.isArray(relData) ? relData : ((relData as Record<string, unknown>).data as Array<Record<string, unknown>>) || [];

            if (Array.isArray(relItems) && relItems.length > 0) {
                for (const item of relItems) {
                if (channels.length >= limit + 3) break;
                const normalized = normalizeLivestream(item);
                if (normalized && !seenUsernames.has(normalized.username)) {
                  channels.push(normalized);
                  seenUsernames.add(normalized.username);
                }
              }
            }
          }
        } catch (error) {
          console.warn(`[recommendations] Related category "${relSlug}" fetch failed:`, (error as Error).message);
        }
      }
    }

    // ── Fallback: Use CATEGORY_CHANNEL_MAP (channel-by-channel approach) ──
    if (channels.length < Math.min(limit, 3) && matchedSlug) {
      // Collect slugs from the primary category + related categories
      const slugsToFetch: string[] = [];
      const seenSlugs = new Set<string>();

      const primaryChannels = CATEGORY_CHANNEL_MAP[matchedSlug] || [];
      for (const s of primaryChannels) {
        if (!seenSlugs.has(s) && !seenUsernames.has(s)) {
          slugsToFetch.push(s);
          seenSlugs.add(s);
        }
      }

      // Add channels from related categories
      const related = RELATED_CATEGORIES[matchedSlug] || [];
      for (const relSlug of related) {
        const relChannels = CATEGORY_CHANNEL_MAP[relSlug] || [];
        for (const s of relChannels) {
          if (!seenSlugs.has(s) && !seenUsernames.has(s)) {
            slugsToFetch.push(s);
            seenSlugs.add(s);
          }
        }
      }

      // Fetch channels in batches of 3

      // Cap slugs to fetch
      const cappedSlugs = slugsToFetch.slice(0, MAX_LOOKUPS);

      for (let i = 0; i < cappedSlugs.length; i += 3) {
        if (channels.length >= limit + 2) break; // fetch a few extra in case some are filtered

        const batch = cappedSlugs.slice(i, i + 3);
        const results = await Promise.all(
          batch.map(async (chSlug) => {
            if (seenUsernames.has(chSlug)) return null;
            try {
              const res = await fetchKickChannel(chSlug);
              if (res.ok && res.data) {
                return normalizeChannel(res.data as Record<string, unknown>);
              }
            } catch {
              // Skip
            }
            return null;
          })
        );

        for (const ch of results) {
          if (ch && !seenUsernames.has(ch.username)) {
            channels.push(ch);
            seenUsernames.add(ch.username);
          }
        }
      }
    }

    // No category match at all — return empty
    if (!matchedSlug && channels.length === 0) {
      return NextResponse.json({ channels: [], category: null });
    }

    // Filter out the source channel (exclude self from recommendations)
    const filtered = channels.filter(ch => {
      const username = ch.username?.toLowerCase();
      return username !== excludeSlug;
    });

    // Sort: live first, then by viewer count
    filtered.sort((a, b) => {
      const aLive = a.isLive ? 1 : 0;
      const bLive = b.isLive ? 1 : 0;
      if (aLive !== bLive) return bLive - aLive;
      return (b.viewerCount || 0) - (a.viewerCount || 0);
    });

    // Get category info
    let categoryInfo: Record<string, unknown> | null = null;
    if (matchedSlug) {
      try {
        const catRes = await fetchKickCategories();
        if (catRes.ok && Array.isArray(catRes.data)) {
          const found = (catRes.data as Array<Record<string, unknown>>).find(
            c => (c.slug as string) === matchedSlug
          );
          if (found) {
            categoryInfo = normalizeCategory(found);
          }
        }
      } catch {
        // Skip category info
      }
    }

    return NextResponse.json({
      channels: filtered.slice(0, limit),
      category: categoryInfo,
    });
  } catch (error) {
    console.error('Recommendations API error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch recommendations' },
      { status: 500 }
    );
  }
}
