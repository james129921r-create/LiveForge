import { NextRequest, NextResponse } from 'next/server';
import { fetchKickChannel, fetchKickCategories, fetchKickCategoryLivestreams } from '@/lib/kick-fetch';
import { normalizeChannel, normalizeLivestream, CATEGORY_CHANNEL_MAP, POPULAR_CHANNELS, CATEGORY_ALIASES, fuzzyScore, validateQuery, normalizeCategory, resolveCategoryAlias } from '@/lib/normalize-channel';
import { ApiCache } from '@/lib/cache';
import { safeParseInt } from '@/lib/parse-utils';
import type { StreamChannel } from '@/types';

// ─── Shared cache for search results ────────────────────────────────────────
const SEARCH_CACHE_TTL_MS = 60_000; // 60 seconds
const searchCache = new ApiCache<Record<string, unknown>>({ maxSize: 200, defaultTtl: SEARCH_CACHE_TTL_MS });

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const query = searchParams.get('q') || '';

  // ─── Pagination / Filter / Sort params ─────────────────────────────────
  const limit = safeParseInt(searchParams.get('limit'), 20, 1, 50);
  const offset = safeParseInt(searchParams.get('offset'), 0, 0);
  const liveOnly = searchParams.get('liveOnly') === 'true';
  const sortBy = searchParams.get('sort') || 'relevance'; // relevance | viewers | recent
  const categoryFilter = searchParams.get('category')?.trim().toLowerCase() || '';
  const langFilter = searchParams.get('lang')?.trim().toLowerCase() || '';

  if (!query.trim()) {
    return NextResponse.json({ channels: [], categories: [], total: 0, limit, offset });
  }

  const queryValidation = validateQuery(query);
  if (!queryValidation.valid || !queryValidation.sanitized) {
    return NextResponse.json(
      { error: 'Invalid search query' },
      { status: 400 }
    );
  }

  const searchQuery = queryValidation.sanitized;
  const searchLower = searchQuery.toLowerCase().replace(/\s+/g, '');

  // Check search cache first (include lang in cache key)
  const cacheKey = `search:${searchLower}:${liveOnly}:${sortBy}:${categoryFilter}:${langFilter}:${limit}:${offset}`;
  const cached = searchCache.get(cacheKey);
  if (cached !== null) {
    return NextResponse.json(cached);
  }

  try {
    const channels: StreamChannel[] = [];
    const seenUsernames = new Set<string>();

    // ─── Strategy 0: Resolve category aliases FIRST ───────────────────────
    // If the user types "asmr", "pool", "hot tub", "gambling" etc., resolve
    // to the canonical Kick category slug and pull known channels from the map.
    const resolvedAlias = resolveCategoryAlias(searchLower);
    const isAliasMatch = resolvedAlias !== searchLower || CATEGORY_ALIASES[searchLower];

    // Cap total channel lookups across ALL strategies to prevent OOM from curl
    const MAX_TOTAL_LOOKUPS = 25;
    let totalLookups = 0;

    if (isAliasMatch) {
      const aliasSlug = CATEGORY_ALIASES[searchLower] || resolvedAlias;
      const knownChannels = CATEGORY_CHANNEL_MAP[aliasSlug];

      if (knownChannels) {
        // Fetch up to 8 channels from the alias-resolved category
        const batch = knownChannels.slice(0, 8);
        totalLookups += batch.length;
        const fetchPromises = batch.map(async (chSlug) => {
          if (seenUsernames.has(chSlug)) return null;
          try {
            const res = await fetchKickChannel(chSlug);
            if (res.ok && res.data) {
              const normalized = normalizeChannel(res.data as Record<string, unknown>);
              if (normalized && !seenUsernames.has(normalized.username.toLowerCase())) {
                return normalized;
              }
            }
          } catch {
            // Skip failed lookups
          }
          return null;
        });

        const results = await Promise.all(fetchPromises);
        for (const ch of results) {
          if (ch) {
            channels.push(ch);
            seenUsernames.add(ch.username.toLowerCase());
          }
        }
      }
    }

    // ─── Strategy 0b: Add the alias-resolved category to results ────────────
    // NOTE: This is deferred to after Strategy 2 because the `categories` variable
    // is declared there. We store the alias info here and use it later.
    let aliasSlugForCategory: string | null = null;
    if (isAliasMatch) {
      const aliasSlug = CATEGORY_ALIASES[searchLower] || resolvedAlias;
      if (CATEGORY_CHANNEL_MAP[aliasSlug]) {
        aliasSlugForCategory = aliasSlug;
      }
    }

    // ─── Strategy 0c: Use /api/v1/streams endpoint for live stream discovery ──
    // When the query matches a category, also fetch from the streams directory
    // filtered by category to find live streams not in our static map.
    if (isAliasMatch && totalLookups < MAX_TOTAL_LOOKUPS) {
      const aliasSlug = CATEGORY_ALIASES[searchLower] || resolvedAlias;
      try {
        // Fetch category livestreams from Kick's API
        const streamsRes = await fetchKickCategoryLivestreams(aliasSlug, 1, 20);
        if (streamsRes.ok && streamsRes.data) {
          const streamsData = streamsRes.data as { data?: Array<Record<string, unknown>> } | Array<Record<string, unknown>>;
          const streamItems = Array.isArray(streamsData) ? streamsData : (streamsData.data || []);

          for (const item of streamItems) {
            if (totalLookups >= MAX_TOTAL_LOOKUPS) break;
            totalLookups++;

            const normalized = normalizeLivestream(item);
            if (normalized && !seenUsernames.has(normalized.username.toLowerCase())) {
              // Apply language filter if specified
              if (langFilter && normalized.language && normalized.language !== langFilter) continue;
              channels.push(normalized);
              seenUsernames.add(normalized.username.toLowerCase());
            }
          }

        }
      } catch (error) {
        console.warn('[search] Strategy 0c failed:', (error as Error).message);
      }
    }

    // ─── Strategy 1: Exact slug lookup ─────────────────────────────────────
    const slug = searchLower.replace(/\s+/g, '');
    if (!seenUsernames.has(slug) && totalLookups < MAX_TOTAL_LOOKUPS) {
      totalLookups++;
      const channelRes = await fetchKickChannel(slug);

      if (channelRes.ok && channelRes.data) {
        const data = channelRes.data as Record<string, unknown>;
        const normalized = normalizeChannel(data);
        if (normalized && !seenUsernames.has(normalized.username.toLowerCase())) {
          channels.push(normalized);
          seenUsernames.add(normalized.username.toLowerCase());
        }
      }
    }

    // ─── Strategy 2: Category name matching ────────────────────────────────
    const catRes = await fetchKickCategories();

    let categories: Record<string, unknown>[] = [];
    if (catRes.ok && Array.isArray(catRes.data)) {
      const allCategories = catRes.data as Array<Record<string, unknown>>;

      // Score each category for fuzzy match
      const scoredCategories = allCategories
        .map((cat) => {
          const name = (cat.name as string || '');
          const catSlug = (cat.slug as string || '');
          const score = Math.max(
            fuzzyScore(searchLower, name),
            fuzzyScore(searchLower, catSlug),
          );
          return { cat, score };
        })
        .filter(({ score }) => score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, 15);

      categories = scoredCategories.map(({ cat, score }) => ({
        ...normalizeCategory(cat),
        score,
      }));
    }

    // ─── Strategy 0b (deferred): Add the alias-resolved category to results ──
    // When the user types "asmr" or "pool", the resolved category should appear
    // in the categories list so the UI can show it as a clickable category card.
    if (aliasSlugForCategory) {
      const alreadyInCategories = categories.some(c => (c.slug as string) === aliasSlugForCategory);
      if (!alreadyInCategories) {
        const { detectMatureContent } = await import('@/lib/mature-content');
        // Format the category name nicely from the slug
        let catName = aliasSlugForCategory
          .replace(/-/g, ' ')
          .replace(/\b\w/g, l => l.toUpperCase());
        // Special cases for known category names
        const KNOWN_NAMES: Record<string, string> = {
          'pools hot tubs and bikinis': 'Pools, Hot Tubs & Bikinis',
          'just chatting': 'Just Chatting',
          'mature gaming': 'Mature Gaming',
          'grand theft auto v': 'Grand Theft Auto V',
          'old school runescape': 'Old School RuneScape',
          'world of warcraft': 'World of Warcraft',
          'counter strike 2': 'Counter-Strike 2',
          'call of duty warzone': 'Call of Duty: Warzone',
          'apex legends': 'Apex Legends',
          'league of legends': 'League of Legends',
          'escape from tarkov': 'Escape from Tarkov',
          'dead by daylight': 'Dead by Daylight',
          'pubg battlegrounds': 'PUBG: Battlegrounds',
          'path of exile': 'Path of Exile',
          'teamfight tactics': 'Teamfight Tactics',
          'diablo iv': 'Diablo IV',
          'overwatch 2': 'Overwatch 2',
          'software and game development': 'Software & Game Development',
          'rocket league': 'Rocket League',
          'rainbow six siege': 'Rainbow Six Siege',
          'sim racing': 'Sim Racing',
          'retro gaming': 'Retro Gaming',
        };
        catName = KNOWN_NAMES[catName.toLowerCase()] || catName;
        const {
          isMature: catIsMature,
          subCategories: catSubCategories,
          contentSection: catContentSection,
          asmrType: catAsmrType,
        } = detectMatureContent([catName]);

        // Fix: General ASMR should NOT be marked as isMature regardless of API flags
        const fixedIsMature = catAsmrType === 'general' ? false : catIsMature;
        const fixedSubCategories = catAsmrType === 'general'
          ? catSubCategories.filter(s => s !== 'nsfw')
          : catSubCategories;
        const fixedContentSection = catAsmrType === 'general' ? 'general' : catContentSection;

        categories.push({
          id: `alias-${aliasSlugForCategory}`,
          name: catName,
          slug: aliasSlugForCategory,
          viewerCount: 0,
          tags: [],
          isMature: fixedIsMature,
          subCategories: fixedSubCategories,
          contentSection: fixedContentSection,
          asmrType: catAsmrType,
          score: 1.0,
        });
      }
    }

    // ─── Strategy 3: Fuzzy match against popular channel names ─────────────
    if (channels.length < limit && totalLookups < MAX_TOTAL_LOOKUPS) {
      const remaining = MAX_TOTAL_LOOKUPS - totalLookups;
      const scoredChannels = POPULAR_CHANNELS
        .map((ch) => ({
          slug: ch,
          score: fuzzyScore(searchLower, ch),
        }))
        .filter(({ score }) => score >= 0.4)
        .sort((a, b) => b.score - a.score)
        .slice(0, Math.min(3, remaining));

      for (const { slug: chSlug } of scoredChannels) {
        if (seenUsernames.has(chSlug)) continue;
        if (channels.length >= limit + offset + 5) break;
        if (totalLookups >= MAX_TOTAL_LOOKUPS) break;
        totalLookups++;
        try {
          const res = await fetchKickChannel(chSlug);
          if (res.ok && res.data) {
            const normalized = normalizeChannel(res.data as Record<string, unknown>);
            if (normalized && !seenUsernames.has(normalized.username.toLowerCase())) {
              channels.push(normalized);
              seenUsernames.add(normalized.username.toLowerCase());
            }
          }
        } catch {
          // Skip failed lookups
        }
      }
    }

    // ─── Strategy 4: Category-to-channel expansion ─────────────────────────
    const matchingCategorySlugs = categories
      .filter((cat) => (cat.score as number || 0) >= 0.5)
      .map((cat) => cat.slug as string);

    // Also add the resolved alias slug if it matches a category
    if (isAliasMatch && !matchingCategorySlugs.includes(resolvedAlias)) {
      matchingCategorySlugs.push(resolvedAlias);
    }

    // Fetch channels from matching categories in parallel batches (reduced to prevent OOM)
    if (channels.length < limit + offset + 5 && totalLookups < MAX_TOTAL_LOOKUPS) {
      const remaining = MAX_TOTAL_LOOKUPS - totalLookups;
      const categoryFetchSlugs = matchingCategorySlugs
        .slice(0, 2)
        .flatMap(catSlug => {
          const known = CATEGORY_CHANNEL_MAP[catSlug];
          if (!known) return [];
          return known.filter(s => !seenUsernames.has(s)).slice(0, Math.min(3, remaining));
        })
        .slice(0, remaining);

      if (categoryFetchSlugs.length > 0) {
        totalLookups += categoryFetchSlugs.length;
        const categoryResults = await Promise.all(
          categoryFetchSlugs.map(async (chSlug) => {
            if (seenUsernames.has(chSlug)) return null;
            try {
              const res = await fetchKickChannel(chSlug);
              if (res.ok && res.data) {
                const normalized = normalizeChannel(res.data as Record<string, unknown>);
                if (normalized && !seenUsernames.has(normalized.username.toLowerCase())) {
                  return normalized;
                }
              }
            } catch {
              // Skip
            }
            return null;
          })
        );
        for (const ch of categoryResults) {
          if (ch && channels.length < limit + offset + 5) {
            channels.push(ch);
            seenUsernames.add(ch.username.toLowerCase());
          }
        }
      }
    }

    // ─── Strategy 5: If category filter is provided, expand from that category ─
    const effectiveCategoryFilter = categoryFilter || (isAliasMatch ? resolvedAlias : '');
    if (effectiveCategoryFilter && CATEGORY_CHANNEL_MAP[effectiveCategoryFilter] && channels.length < limit + offset + 5 && totalLookups < MAX_TOTAL_LOOKUPS) {
      const remaining = MAX_TOTAL_LOOKUPS - totalLookups;
      const catChannels = CATEGORY_CHANNEL_MAP[effectiveCategoryFilter]!
        .filter(s => !seenUsernames.has(s))
        .slice(0, Math.min(6, remaining));

      if (catChannels.length > 0) {
        totalLookups += catChannels.length;
        const s5Results = await Promise.all(
          catChannels.map(async (chSlug) => {
            try {
              const res = await fetchKickChannel(chSlug);
              if (res.ok && res.data) {
                const normalized = normalizeChannel(res.data as Record<string, unknown>);
                if (normalized && !seenUsernames.has(normalized.username.toLowerCase())) {
                  return normalized;
                }
              }
            } catch {
              // Skip
            }
            return null;
          })
        );
        for (const ch of s5Results) {
          if (ch && channels.length < limit + offset + 5) {
            channels.push(ch);
            seenUsernames.add(ch.username.toLowerCase());
          }
        }
      }
    }

    // ─── Apply filters ──────────────────────────────────────────────────────
    let filtered = channels;

    if (liveOnly) {
      filtered = filtered.filter(ch => ch.isLive);
    }

    if (categoryFilter) {
      filtered = filtered.filter(ch => {
        const chCat = (ch.category || '').toLowerCase().replace(/\s+/g, '-');
        return chCat.includes(categoryFilter) || categoryFilter.includes(chCat);
      });
    }

    // Apply language filter
    if (langFilter) {
      filtered = filtered.filter(ch => {
        // If the channel has a language field, filter by it
        if (ch.language) return ch.language === langFilter;
        // If no language info, include by default (don't exclude channels without language data)
        return true;
      });
    }

    // ─── Sort ───────────────────────────────────────────────────────────────
    switch (sortBy) {
      case 'viewers':
        filtered.sort((a, b) => (b.viewerCount || 0) - (a.viewerCount || 0));
        break;
      case 'recent':
        filtered.sort((a, b) => {
          // Sort by startedAt (most recent first)
          const aTime = a.startedAt;
          const bTime = b.startedAt;
          if (!aTime && !bTime) return 0;
          if (!aTime) return 1;
          if (!bTime) return -1;
          return new Date(bTime).getTime() - new Date(aTime).getTime();
        });
        break;
      case 'relevance':
      default:
        // Enhanced relevance scoring with boost factors
        filtered.sort((a, b) => {
          const aLive = a.isLive ? 1 : 0;
          const bLive = b.isLive ? 1 : 0;
          if (aLive !== bLive) return bLive - aLive;

          // Compute relevance scores for both channels
          const aScore = computeRelevanceScore(a, searchLower);
          const bScore = computeRelevanceScore(b, searchLower);

          // Sort by relevance score (higher is better), then by viewer count
          if (bScore !== aScore) return bScore - aScore;
          return (b.viewerCount || 0) - (a.viewerCount || 0);
        });
        break;
    }

    const total = filtered.length;
    const paginated = filtered.slice(offset, offset + limit);

    // ─── If no channels found, provide helpful hints ────────────────────────
    const hints: string[] = [];
    if (channels.length === 0) {
      if (catRes.cloudflareBlocked) {
        hints.push('Kick API blocked by Cloudflare. Configure KICK_PROXY_URL to bypass.');
      }
      if (isAliasMatch) {
        hints.push(`Searched category "${resolvedAlias}" but no channels were found. The streamers may be offline.`);
      }
    }

    const result = {
      channels: paginated,
      categories,
      total,
      limit,
      offset,
      ...(hints.length > 0 ? { _hints: hints } : {}),
    };

    // Cache the result
    searchCache.set(cacheKey, result);

    return NextResponse.json(result);
  } catch (error) {
    console.error('Kick search API error:', error);
    return NextResponse.json(
      { error: 'Search failed' },
      { status: 500 }
    );
  }
}

/**
 * Compute a relevance score for a channel based on how well it matches the search query.
 * Used for the 'relevance' sort mode.
 *
 * Boost factors:
 *  - Exact display name match: 2x boost
 *  - Stream title contains query: 1.5x boost
 *  - Category matches query: 1.3x boost
 *  - Base score: viewer count (log-scaled for fairness)
 */
function computeRelevanceScore(channel: StreamChannel, query: string): number {
  // Base score from viewer count (log-scaled so mega-streamers don't dominate)
  const baseScore = channel.viewerCount ? Math.log10(channel.viewerCount + 1) : 0;

  let multiplier = 1.0;

  const queryLower = query.toLowerCase();
  const displayNameLower = (channel.displayName || '').toLowerCase().replace(/\s+/g, '');
  const titleLower = (channel.title || '').toLowerCase();
  const categoryLower = (channel.category || '').toLowerCase().replace(/\s+/g, '-');

  // Exact display name match → 2x boost
  if (displayNameLower === queryLower || displayNameLower === query) {
    multiplier *= 2.0;
  } else if (displayNameLower.includes(queryLower)) {
    // Partial display name match → 1.5x boost
    multiplier *= 1.5;
  }

  // Stream title contains query → 1.5x boost
  if (titleLower.includes(queryLower)) {
    multiplier *= 1.5;
  }

  // Category matches query → 1.3x boost
  if (categoryLower.includes(queryLower) || queryLower.includes(categoryLower)) {
    multiplier *= 1.3;
  }

  return baseScore * multiplier;
}
