import { NextResponse } from 'next/server';
import { fetchKickStreams, fetchKickChannel } from '@/lib/kick-fetch';
import { normalizeLivestream, normalizeChannel, POPULAR_CHANNELS, CATEGORY_CHANNEL_MAP } from '@/lib/normalize-channel';
import type { StreamChannel } from '@/types';

/**
 * GET /api/kick/trending
 *
 * Returns categorized discovery lanes:
 *   - trending: Streams with high viewer counts relative to their follower count
 *     (proxy for rapid growth — a stream with 5k viewers but 10k followers is
 *     growing faster than one with 20k viewers and 1M followers)
 *   - rising: Streams in the 100-2000 viewer range
 *   - newStreamers: Streams with <100 viewers that just went live
 *
 * Primary: Fetches from /api/v1/streams pages 1 and 2.
 * Fallback: If streams endpoint is unavailable (Kick API changes), fetches
 * channels from POPULAR_CHANNELS and category maps to populate lanes.
 *
 * In-memory cache with 90-second TTL.
 */

interface CacheEntry {
  trending: StreamChannel[];
  rising: StreamChannel[];
  newStreamers: StreamChannel[];
  timestamp: number;
}

const CACHE_TTL_MS = 90_000;
let cachedEntry: CacheEntry | null = null;

export async function GET() {
  // Check cache
  if (cachedEntry && Date.now() - cachedEntry.timestamp < CACHE_TTL_MS) {
    return NextResponse.json({
      trending: cachedEntry.trending,
      rising: cachedEntry.rising,
      newStreamers: cachedEntry.newStreamers,
    });
  }

  try {
    let allStreams: StreamChannel[] = [];
    const seenUsernames = new Set<string>();

    // ── Primary: Use /api/v1/streams endpoint ──────────────────────────────
    try {
      const [page1Res, page2Res] = await Promise.all([
        fetchKickStreams(1, 50),
        fetchKickStreams(2, 50),
      ]);

      // Process page 1
      if (page1Res.ok && page1Res.data) {
        const data = page1Res.data as { data?: Array<Record<string, unknown>> } | Array<Record<string, unknown>>;
        const items = Array.isArray(data) ? data : (data.data || []);
        for (const item of items) {
          const normalized = normalizeLivestream(item);
          if (normalized && !seenUsernames.has(normalized.username)) {
            allStreams.push(normalized);
            seenUsernames.add(normalized.username);
          }
        }
      }

      // Process page 2
      if (page2Res.ok && page2Res.data) {
        const data = page2Res.data as { data?: Array<Record<string, unknown>> } | Array<Record<string, unknown>>;
        const items = Array.isArray(data) ? data : (data.data || []);
        for (const item of items) {
          const normalized = normalizeLivestream(item);
          if (normalized && !seenUsernames.has(normalized.username)) {
            allStreams.push(normalized);
            seenUsernames.add(normalized.username);
          }
        }
      }
    } catch {
      // Streams endpoint unavailable
    }

    // ── Fallback: Channel-by-channel from popular + category maps ─────────
    if (allStreams.length < 5) {
      // Build a combined slug list from popular channels and a few from top categories
      const fallbackSlugs = new Set<string>(POPULAR_CHANNELS);
      // Add some channels from the top categories
      const topCategories = ['just-chatting', 'irl', 'slots', 'grand-theft-auto-v', 'rust', 'counter-strike-2', 'valorant', 'asmr'];
      for (const cat of topCategories) {
        const catChannels = CATEGORY_CHANNEL_MAP[cat];
        if (catChannels) {
          for (const slug of catChannels.slice(0, 5)) {
            fallbackSlugs.add(slug);
          }
        }
      }

      // Deduplicate and exclude already-fetched
      const slugsToFetch = [...fallbackSlugs].filter(s => !seenUsernames.has(s)).slice(0, 40);

      // Fetch in batches of 4
      for (let i = 0; i < slugsToFetch.length; i += 4) {
        const batch = slugsToFetch.slice(i, i + 4);
        const results = await Promise.all(
          batch.map(async (chSlug) => {
            try {
              const res = await fetchKickChannel(chSlug);
              if (res.ok && res.data) {
                return normalizeChannel(res.data as Record<string, unknown>);
              }
            } catch {
              // Skip
            }
            return null;
          })
        );

        for (const ch of results) {
          if (ch && !seenUsernames.has(ch.username)) {
            allStreams.push(ch);
            seenUsernames.add(ch.username);
          }
        }
      }
    }

    if (allStreams.length === 0) {
      return NextResponse.json({
        trending: [],
        rising: [],
        newStreamers: [],
      });
    }

    // ── Compute Trending ─────────────────────────────────────────────────
    // Streams with high viewers-to-followers ratio (proxy for rapid growth)
    // A stream with 5k viewers / 10k followers = 0.5 ratio (trending!)
    // A stream with 20k viewers / 1M followers = 0.02 ratio (established)
    const trending = [...allStreams]
      .filter(ch => ch.isLive && (ch.viewerCount || 0) > 500)
      .map(ch => ({
        channel: ch,
        // Ratio of viewers to followers (higher = more trending)
        // Use log scale for followers to prevent division by tiny numbers
        growthScore: (ch.viewerCount || 0) / Math.max(Math.log10((ch.followersCount || 100) + 1) * 100, 100),
      }))
      .sort((a, b) => b.growthScore - a.growthScore)
      .slice(0, 8)
      .map(item => item.channel);

    // ── Compute Rising ───────────────────────────────────────────────────
    // Streams in the 100-2000 viewer range that are growing
    const rising = [...allStreams]
      .filter(ch => ch.isLive && (ch.viewerCount || 0) >= 100 && (ch.viewerCount || 0) <= 2000)
      .sort((a, b) => (b.viewerCount || 0) - (a.viewerCount || 0))
      .slice(0, 8);

    // ── Compute New Streamers ────────────────────────────────────────────
    // Streams with <100 viewers that recently went live
    const newStreamers = [...allStreams]
      .filter(ch => ch.isLive && (ch.viewerCount || 0) < 100 && (ch.viewerCount || 0) > 0)
      .sort((a, b) => {
        // Prefer streams that just went live
        const aUptime = a.uptimeMinutes ?? 999;
        const bUptime = b.uptimeMinutes ?? 999;
        return aUptime - bUptime;
      })
      .slice(0, 8);

    // Update cache
    cachedEntry = {
      trending,
      rising,
      newStreamers,
      timestamp: Date.now(),
    };

    return NextResponse.json({
      trending,
      rising,
      newStreamers,
    });
  } catch (error) {
    console.error('Trending API error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch trending streams' },
      { status: 500 }
    );
  }
}
