import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  // Re-enable strict mode for better React consistency checks
  reactStrictMode: true,
  // Keep ignoring TS build errors for now — the project has pre-existing
  // issues in example/test files. Should be removed once those are fixed.
  typescript: {
    ignoreBuildErrors: true,
  },
};

export default nextConfig;
